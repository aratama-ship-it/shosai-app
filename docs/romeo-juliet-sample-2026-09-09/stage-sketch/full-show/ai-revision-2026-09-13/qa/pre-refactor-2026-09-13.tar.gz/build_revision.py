#!/usr/bin/env python3
"""Build the isolated AI showwright for StageSketch revision."""

from __future__ import annotations

from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
FULL_SHOW = HERE.parent
M6 = FULL_SHOW / "m6-transition-candidate"
REPO = HERE.parents[4]
SOURCE = FULL_SHOW / "romeo-juliet-full-show.stage-sketch.json"
AI_INPUT = M6 / "ai-input.json"
AI_PROPOSAL = M6 / "ai-proposal.json"
OWNER_APPROVAL = M6 / "owner-approval-2026-09-12.json"
OUTPUT = HERE / "romeo-juliet-full-show-ai-revised.stage-sketch.json"
MANIFEST = HERE / "ai-change-manifest.json"
TEMPLATE = HERE / "index.template.html"
INDEX = HERE / "index.html"

EXPECTED_SOURCE_SHA256 = "7086d75a843a0ea7253d3dd630defe994cf491432aabcc19e7774d5000a5d780"
SYSTEM_NAME = "AI showwright for StageSketch"
FROM_ID = "rj-frame-rj-cond-01-b-02"
TO_ID = "rj-frame-rj-cond-01-c-01"
BAR_ID = "rj-set-bar"
SHELF_ID = "rj-set-bar-shelf"
CARRIERS = ("FRIAR_LAWRENCE", "FRIAR_JOHN")
BAR_DIMS = {"w": 2.4, "d": 0.6, "h": 1.1}

LIGHTING_OBJECTIVES = {
    "rj-frame-rj-cond-01-a-01": "舞台全体の明かりを保ちながら中央へ穏やかなスポットを置き、制止する人物を見せる。",
    FROM_ID: "挑発を合図に即時ブラックアウトし、舞台監督の再照明指示まで暗転を維持する。",
    TO_ID: "客席右手前の二人を柔らかく照らし、バーを暖色で見せながら、残る八名にも最低限の明るさを残す。",
    "rj-frame-rj-cond-01-d-01": "室内の暖かな光を消し、客席右手前の二人だけを残す。",
    "rj-frame-rj-cond-02-a-01": "客席右手前の二人を保ち、退場後に焦点を中央へ移す。",
    "rj-frame-rj-cond-02-b-01": "暗転せず客席右手前から中央へ焦点を移し、色温度で翌日を示す。",
    "rj-frame-rj-cond-02-c-01": "中央を柔らかく照らし、婚姻後に街路全体へ静かに明かりを開く。",
    "rj-frame-rj-cond-03-a-01": "舞台全体を一つの街路として照らし、左右を家ごとの色に分けない。",
    "rj-frame-rj-cond-03-a-02": "舞台全体を一つの街路として照らし、左右を家ごとの色に分けない。",
    "rj-frame-rj-cond-03-b-01": "二人の殺陣が見える街路の明かりを固定し、途中で見え方を切り替えない。",
    "rj-frame-rj-cond-03-c-01": "負傷と報復が見える明かりを保ち、決着後に焦点をゆっくり絞る。",
    "rj-frame-rj-cond-03-c-02": "負傷と報復が見える明かりを保ち、決着後に焦点をゆっくり絞る。",
    "rj-frame-rj-cond-03-c-03": "負傷と報復が見える明かりを保ち、決着後に焦点をゆっくり絞る。",
    "rj-frame-rj-cond-03-d-01": "裁きから客席右手前の夜、夜明けへ光を移し、明るさとともに二人の距離を見せる。",
    "rj-frame-rj-cond-03-d-02": "裁きから客席右手前の夜、夜明けへ光を移し、明るさとともに二人の距離を見せる。",
    "rj-frame-rj-cond-04-a-01": "客席右の家の領域を照らし、父娘の距離を誇張しすぎず見せる。",
    "rj-frame-rj-cond-04-b-01": "中央の瓶から手紙へ焦点を渡し、最後に客席右の部屋を照らす。",
    "rj-frame-rj-cond-04-b-02": "中央の瓶から手紙へ焦点を渡し、最後に客席右の部屋を照らす。",
    "rj-frame-rj-cond-04-c-01": "一人の夜、発見の朝、葬送へ暗転なしで光を移し、時間と場所を見せる。",
    "rj-frame-rj-cond-04-c-02": "一人の夜、発見の朝、葬送へ暗転なしで光を移し、時間と場所を見せる。",
    "rj-frame-rj-cond-04-d-01": "舞台全体の旅路から、左の墓所と右の修道士の場所へ光を分けて開く。",
    "rj-frame-rj-cond-04-d-02": "舞台全体の旅路から、左の墓所と右の修道士の場所へ光を分けて開く。",
    "rj-frame-rj-cond-05-a-01": "左の墓所と右の別場所を同時に照らし、中央の人の流れも読める明るさを残す。",
    "rj-frame-rj-cond-05-b-01": "暗転せず目覚めの微細な動きを見せ、二人が静まった後に左右の光をそろえる。",
    "rj-frame-rj-cond-05-b-02": "暗転せず目覚めの微細な動きを見せ、二人が静まった後に左右の光をそろえる。",
    "rj-frame-rj-cond-05-c-01": "中央の境界を光で消し、中央のロレンスと左の二人を一つの場として見せる。",
    "rj-frame-rj-cond-05-d-01": "中央のロレンスと一人ずつ近づく人を照らし、二人の遺体を残して最後に全体をフェードする。",
    "rj-frame-rj-cond-05-d-02": "中央のロレンスと一人ずつ近づく人を照らし、二人の遺体を残して最後に全体をフェードする。",
}


def digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def dump(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def slug(role: str) -> str:
    return role.lower().replace("_", "-")


def people_by_role(scene: dict) -> dict[str, dict]:
    return {
        piece["originId"]: piece
        for piece in scene.get("pieces", [])
        if piece.get("type") == "performer"
    }


def pieces_by_set(scene: dict) -> dict[str, dict]:
    return {
        piece["setId"]: piece
        for piece in scene.get("pieces", [])
        if piece.get("setId")
    }


def set_bar_shape(document: dict, dims: dict[str, float]) -> None:
    project = document["project"]
    project["sets"] = [item for item in project["sets"] if item["id"] != SHELF_ID]
    bar_asset = next(item for item in project["sets"] if item["id"] == BAR_ID)
    bar_asset.update({
        "name": "キャスター付き一体型バー",
        "kind": "prop",
        "propShape": "counter",
        "dims": deepcopy(dims),
        "note": "Stage Sketch既存のcounter形状へ型割当を修正。寸法はcounter既定値であり実測値・搬入可否・安全性を示さない。",
        "estimated": True,
        "confidence": "unverified",
        "sourceNote": "元生成物のblock 10.08m指定を、現行Stage Sketchのcounter 2.4×0.6×1.1mへ修正。背面棚は移動バーと別物のため本案では置かない。",
    })
    for scene in project["scenes"]:
        if scene.get("kind") != "scene":
            continue
        scene["pieces"] = [piece for piece in scene.get("pieces", []) if piece.get("setId") != SHELF_ID]
        for piece in scene["pieces"]:
            if piece.get("setId") == BAR_ID:
                piece.update({
                    "type": "prop",
                    "propShape": "counter",
                    "name": "キャスター付き一体型バー",
                    "dims": deepcopy(dims),
                })


def mask_for(scene_id: str, holder: dict, template: dict, worn: bool) -> dict:
    mask = deepcopy(template)
    mask["id"] = f"{scene_id}-{mask['setId']}"
    mask["u"] = holder["u"]
    mask["v"] = holder["v"]
    mask["heldBy"] = holder["id"]
    mask["holdMode"] = "face" if worn else "hand"
    mask["holdSide"] = "R"
    mask["route"] = None
    return mask


def transition_lighting(frame_id: str) -> dict:
    return {
        "version": 1,
        "objective": "客席に何も見せないブラックアウトを維持し、転換工程を技術確認図として記録する。",
        "audienceFocus": "客席へ見せない暗転中の技術確認図。",
        "layers": {
            "performer": {"intent": "conceal", "note": "暗転を維持し、人物移動と仮面装着を客席から隠す。"},
            "background": {"intent": "conceal", "note": "バー搬入を客席から隠す。"},
            "space": {"intent": "conceal", "note": "通路と固定状態は舞台監督が手動確認する。"},
        },
        "transition": {
            "triggerType": "manual",
            "triggerNote": "バー固定・通路クリア・10人の位置・全員の仮面・照明準備を舞台監督が手動確認。自動GOなし。",
            "change": "hold",
            "tempo": "hold",
        },
        "mood": "",
        "referenceNote": f"M6-SAMPLE-A / {frame_id}",
        "implementationNote": "技術確認図。実物・稽古・搬入・安全の承認ではない。",
        "safetyStatus": "not-assessed",
        "sourceRefs": [{"kind": "user", "label": "M6本人確定条件", "locator": "owner-approval-2026-09-12.json"}],
    }


def build_transition_scene(frame: dict, q02: dict, q03: dict, mask_templates: dict[str, dict]) -> dict:
    scene = deepcopy(q03)
    scene.update({
        "id": frame["id"],
        "title": frame["title"],
        "note": frame["note"],
        "pieces": [],
        "notes": [],
        "strokes": [],
        "arrows": [],
        "studyBeatId": None,
        "beat": {"role": frame["role"], "energy": None},
        "rehearsal": {"holdDurationSeconds": None, "transitionToNextSeconds": None},
        "lightingIntent": transition_lighting(frame["id"]),
        "cueSeconds": None,
        "audioTrackId": None,
        "blackout": True,
    })

    starts = people_by_role(q02)
    goals = people_by_role(q03)
    for role, start in starts.items():
        goal = goals[role]
        person = deepcopy(goal)
        person["id"] = f"{frame['id']}-{slug(role)}"
        person["u"] = round(start["u"] + (goal["u"] - start["u"]) * frame["progress"], 4)
        person["v"] = round(start["v"] + (goal["v"] - start["v"]) * frame["progress"], 4)
        person["pose"] = "walk"
        person["route"] = None
        if role in frame["carrierPositions"]:
            person.update(frame["carrierPositions"][role])
            person["name"] = "運搬担当（ロレンス担当）" if role == CARRIERS[0] else "運搬担当（ジョン担当）"
        scene["pieces"].append(person)

    people = people_by_role(scene)
    if frame.get("bar"):
        bar = deepcopy(pieces_by_set(q03)[BAR_ID])
        bar["id"] = f"{frame['id']}-{BAR_ID}"
        bar["u"] = frame["bar"]["u"]
        bar["v"] = frame["bar"]["v"]
        bar["route"] = None
        if frame["bar"]["u"] != frame["bar"]["targetU"]:
            bar["route"] = {
                "u": frame["bar"]["targetU"],
                "v": frame["bar"]["targetV"],
                "bu": 0.70,
                "bv": 0.10,
            }
        scene["pieces"].append(bar)

    worn_roles = set(frame["maskRoles"])
    for role, holder in people.items():
        scene["pieces"].append(mask_for(scene["id"], holder, mask_templates[role], role in worn_roles))
    return scene


def render_sources(manifest: dict) -> str:
    labels = {
        "sourceNative": "元ファイル",
        "aiInput": "AI入力",
        "aiProposal": "AI提案",
        "ownerApproval": "本人承認記録",
    }
    hrefs = {
        "sourceNative": "../romeo-juliet-full-show.stage-sketch.json",
        "aiInput": "../m6-transition-candidate/ai-input.json",
        "aiProposal": "../m6-transition-candidate/ai-proposal.json",
        "ownerApproval": "../m6-transition-candidate/owner-approval-2026-09-12.json",
    }
    rows = []
    for key in labels:
        rows.append(
            f'<li><a href="{hrefs[key]}">{labels[key]}</a><code>{manifest["sources"][key]["sha256"]}</code></li>'
        )
    rows.append('<li><a href="ai-change-manifest.json">AI変更台帳</a><code>生成物</code></li>')
    rows.append('<li><a href="qa/structure-checks.json">構造検査結果</a><code>実行後生成</code></li>')
    rows.append('<li><a href="qa/browser-checks.json">ブラウザ読込試験</a><code>実行後生成</code></li>')
    return "\n".join(rows)


def build() -> None:
    if digest(SOURCE) != EXPECTED_SOURCE_SHA256:
        raise SystemExit("Source JSON hash changed. Re-review before rebuilding.")

    document = load(SOURCE)
    proposal = load(AI_PROPOSAL)
    approval = load(OWNER_APPROVAL)
    if approval.get("status") != "owner_approved_for_sample":
        raise SystemExit("Owner approval is not valid for the sample.")
    if [item.get("choice") for item in approval.get("decisions", [])] != ["A", "A", "A"]:
        raise SystemExit("Expected the recorded M6 A/A/A owner decisions.")
    project = document["project"]
    original_project_id = project["id"]
    original_scene_count = sum(scene.get("kind") == "scene" for scene in project["scenes"])
    original_set_count = len(project["sets"])
    original_duplicate_count = sum(
        scene.get("kind") == "scene"
        and scene.get("beat", {}).get("role", "").strip()
        and scene.get("beat", {}).get("role", "").strip() == scene.get("lightingIntent", {}).get("objective", "").strip()
        for scene in project["scenes"]
    )

    project.update({
        "id": "romeo-juliet-full-show-ai-revised-2026-09-13",
        "title": "ロミオとジュリエット｜全編サンプル（AI showwright for StageSketch 改訂）",
        "versionLabel": "AI showwright for StageSketch 改訂 2026-09-13",
        "parentVersionId": original_project_id,
        "branchReason": "元ショーを上書きしない隔離AI改訂。M6本人確定条件、バーの型割当修正、照明意図の意味修正を反映。",
        "createdAt": "2026-09-13T00:00:00+09:00",
    })

    set_bar_shape(document, BAR_DIMS)
    scenes = project["scenes"]
    q02 = next(scene for scene in scenes if scene.get("id") == FROM_ID)
    q03 = next(scene for scene in scenes if scene.get("id") == TO_ID)

    # The approved bar carriers become anonymous bar staff at the Q03 destination.
    q03_people = people_by_role(q03)
    for role, position in proposal["barStaffPositions"].items():
        q03_people[role].update(position)
        q03_people[role]["name"] = "バー係（ロレンス担当）" if role == CARRIERS[0] else "バー係（ジョン担当）"

    q03_sets = pieces_by_set(q03)
    mask_templates = {role: deepcopy(q03_sets[f"rj-mask-{slug(role)}"]) for role in q03_people}

    # All ten masks are explicitly carried before blackout. `hand` is the closest
    # Stage Sketch representation for carried; it does not assert literal hand use.
    q02_people = people_by_role(q02)
    for role, position in proposal["preBlackoutPositions"].items():
        q02_people[role].update(position)
        q02_people[role]["route"] = None
    for role, holder in q02_people.items():
        q02["pieces"].append(mask_for(q02["id"], holder, mask_templates[role], worn=False))

    q02["note"] = "【本人確定条件反映】10名は暗転前から仮面を携帯。ロレンス担当とジョン担当は右袖寄りへ準備し、暗転後に役を離れてバーを運ぶ。携帯表示のhandは模式表現で、実際の手の使い方は未確認。"
    q02["rehearsal"] = {"holdDurationSeconds": None, "transitionToNextSeconds": None}
    q02["lightingIntent"]["layers"]["performer"]["note"] = "挑発を合図に即暗転。舞台監督が5条件を手動確認して再照明を指示するまで暗転を維持する。"
    q02["lightingIntent"]["transition"] = {
        "triggerType": "manual",
        "triggerNote": "バー固定・通路クリア・10人の位置・全員の仮面・照明準備を手動確認。バーが遅れた場合は暗転維持、設置完了後に再照明し遅延を記録。",
        "change": "blackout",
        "tempo": "hold",
    }

    approved_frames = []
    roles = set(q03_people)
    for index, source_frame in enumerate(proposal["frames"]):
        frame = deepcopy(source_frame)
        frame["bar"] = deepcopy(frame.get("bar"))
        if frame["bar"] and index == 1:
            frame["bar"]["u"] = 0.92
        if index == 0:
            frame["role"] = "暗転直後に人物移動と仮面装着を始め、バー担当二名が右袖側へ寄る。"
            frame["note"] = "【本人確定＋AI配置案・客席へ見せない技術図】人物移動と4名の仮面装着を開始。バーはまだ出さない。担当2名は右袖側へ寄る。順序・座標は未稽古。"
        elif index == 1:
            frame["role"] = "複数の変化の途中で、二名が右袖から一体型バーを押し入れる。"
            frame["note"] = "【本人確定＋AI配置案・客席へ見せない技術図】途中で二名が客席から見て右袖から一体型バーを押す。バー寸法・経路・視界・手の使い方は未確認。"
        else:
            frame["role"] = "バー固定後、担当二名も仮面を着けてバー係位置へ移り、再照明確認を待つ。"
            frame["note"] = "【本人確定＋AI配置案・客席へ見せない技術図】バー固定後、担当2名も仮面を着けてバー係位置へ移る。舞台監督の5条件確認まで暗転を維持。"
        if not set(frame["maskRoles"]).issubset(roles):
            raise SystemExit(f"Unknown mask role in {frame['id']}")
        approved_frames.append(build_transition_scene(frame, q02, q03, mask_templates))

    for current, following in zip(approved_frames, approved_frames[1:]):
        now = people_by_role(current)
        nxt = people_by_role(following)
        for role in CARRIERS:
            now[role]["route"] = {
                "u": nxt[role]["u"],
                "v": nxt[role]["v"],
                "bu": round((now[role]["u"] + nxt[role]["u"]) / 2, 4),
                "bv": max(0.06, round(min(now[role]["v"], nxt[role]["v"]) - 0.03, 4)),
            }

    source_index = next(i for i, scene in enumerate(scenes) if scene.get("id") == FROM_ID)
    if scenes[source_index + 1].get("id") != TO_ID:
        raise SystemExit("Q02 and Q03 are no longer adjacent in the source.")
    project["scenes"] = scenes[: source_index + 1] + approved_frames + scenes[source_index + 1 :]

    q03["note"] = "【本人確定＋型割当修正】全員が仮面を着け、二名はバー固定後にバー係位置へ移る。バーはStage Sketch既存counter形状。既定寸法は実測値ではなく未確認。"
    q03["blackout"] = True

    missing_objectives = []
    for scene in project["scenes"]:
        if scene.get("kind") != "scene" or scene["id"] in {item["id"] for item in approved_frames}:
            continue
        objective = LIGHTING_OBJECTIVES.get(scene["id"])
        if not objective:
            missing_objectives.append(scene["id"])
            continue
        scene["lightingIntent"]["objective"] = objective
    if missing_objectives:
        raise SystemExit(f"Lighting objective missing for: {missing_objectives}")

    dump(OUTPUT, document)
    output_sha = digest(OUTPUT)
    product_files = {}
    for name in ("index.html", "stage.html", "stage-sketch.js", "style.css"):
        path = REPO / name
        product_files[name] = {"path": str(path.relative_to(REPO)), "sha256AtBuild": digest(path)}

    manifest = {
        "kind": "stage-sketch-ai-change-manifest",
        "version": 1,
        "systemName": SYSTEM_NAME,
        "status": "isolated_ai_revision_with_owner_review_required",
        "generatedAt": "2026-09-13T00:00:00+09:00",
        "scope": "Romeo and Juliet full-show sample only; no production source changes",
        "sources": {
            "sourceNative": {"path": "../romeo-juliet-full-show.stage-sketch.json", "sha256": digest(SOURCE)},
            "aiInput": {"path": "../m6-transition-candidate/ai-input.json", "sha256": digest(AI_INPUT)},
            "aiProposal": {"path": "../m6-transition-candidate/ai-proposal.json", "sha256": digest(AI_PROPOSAL)},
            "ownerApproval": {"path": "../m6-transition-candidate/owner-approval-2026-09-12.json", "sha256": digest(OWNER_APPROVAL)},
        },
        "output": {"path": OUTPUT.name, "sha256": output_sha},
        "protectedProductFiles": product_files,
        "counts": {
            "sourceScenes": original_scene_count,
            "revisedScenes": sum(scene.get("kind") == "scene" for scene in project["scenes"]),
            "insertedM6TechnicalScenes": 3,
            "sourceSets": original_set_count,
            "revisedSets": len(project["sets"]),
            "removedShelfAssets": 1,
            "sourceIdenticalRoleLightingObjectives": original_duplicate_count,
            "revisedIdenticalRoleLightingObjectives": 0,
        },
        "confirmed": [
            "M6は乱戦ブラックアウトから仮面舞踏会とバーセットへの転換",
            "ロレンス担当とジョン担当が役を離れ、右袖から一体型バーを二人で押して固定",
            "バーは複数の変化の途中で搬入し、最初と最後には出さない",
            "10名は暗転前から仮面を携帯し、バー担当二名は固定後に着けてバー係位置へ移る",
            "暗転中の技術確認図は3枚",
            "M6所要時間と転換締切は未計測のためnull",
            "再照明は舞台監督が5条件を手動確認して指示。未完了時は暗転維持と遅延記録",
        ],
        "aiProposals": [
            "バーは現行Stage Sketchの既存counter形状へ割り当て。2.4×0.6×1.1mはシステム既定値で実測値ではない",
            "背面棚は移動バーと別物であり、存在も未確定のため主JSONから除外",
            "携帯中の仮面はStage Sketch上でholdMode=handと表示。実際の手の使い方を確定しない",
            "人物位置、バー搬入経路、仮面装着順はAI配置案",
        ],
        "unconfirmed": [
            "バーの正確な幅・奥行・高さ・意匠・キャスター仕様",
            "固定の背面棚を置くかどうか、および置く場合の寸法と位置",
            "実会場の袖幅・搬入経路・バミリ・床条件・二名での取扱安全性",
            "M6の所要時間、転換締切、各工程の実行可能性",
            "仮面携帯時の実際の保持方法とバーを押す際の手の使い方",
        ],
        "changes": [
            {"path": "project.id/title/versionLabel/parentVersionId/branchReason", "reason": "元ショーと区別できる隔離改訂"},
            {"path": "project.sets[rj-set-bar]", "before": {"kind": "block", "dims": {"w": 10.08, "d": 0.65, "h": 1.0}}, "after": {"kind": "prop", "propShape": "counter", "dims": BAR_DIMS}, "reason": "元生成スクリプトの型・寸法指定を現行Stage Sketch既存形状へ修正"},
            {"path": "project.sets[rj-set-bar-shelf]", "before": "10.08m wall", "after": None, "reason": "移動バーと無条件に一体運用しない"},
            {"path": "Q02→Q03", "after": "暗転中技術確認図3枚、10枚の仮面状態、右袖からのバー搬入、手動再照明条件"},
            {"path": "Q02.rehearsal + inserted M6 rehearsal", "after": {"holdDurationSeconds": None, "transitionToNextSeconds": None}},
            {"path": "all scene lightingIntent.objective", "after": "照明が何を見せるかを記述し、beat.roleとの同文重複を解消"},
        ],
        "barDisplayCorrection": {
            "classification": "source-generator mapping correction",
            "ownerShapeDecisionRequired": False,
            "stageSketchKind": "prop",
            "stageSketchPropShape": "counter",
            "systemDefaultDims": BAR_DIMS,
            "actualDimensionsConfirmed": False,
        },
        "approvalEvidence": approval,
    }
    dump(MANIFEST, manifest)

    template = TEMPLATE.read_text(encoding="utf-8")
    safe_document_json = json.dumps(document, ensure_ascii=False).replace("</", "<\\/")
    safe_manifest_json = json.dumps(manifest, ensure_ascii=False).replace("</", "<\\/")
    html = template.replace("@@DOCUMENT_JSON@@", safe_document_json)
    html = html.replace("@@MANIFEST_JSON@@", safe_manifest_json)
    html = html.replace("@@SOURCE_ROWS@@", render_sources(manifest))
    html = html.replace("@@OUTPUT_SHA@@", output_sha)
    INDEX.write_text(html, encoding="utf-8")
    print(f"wrote {OUTPUT.relative_to(REPO)}")
    print(f"sha256 {output_sha}")
    print(f"wrote {MANIFEST.relative_to(REPO)}")
    print(f"wrote {INDEX.relative_to(REPO)}")


if __name__ == "__main__":
    build()
