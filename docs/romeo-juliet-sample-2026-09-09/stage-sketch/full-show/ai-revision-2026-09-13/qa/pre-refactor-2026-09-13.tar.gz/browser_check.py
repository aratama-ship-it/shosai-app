#!/usr/bin/env python3
"""Compatibility launcher for the bundled-Playwright browser_check.cjs."""

from __future__ import annotations

import hashlib
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import subprocess
import sys
import threading

if __name__ == "__main__":
    runtime_root = Path.home() / ".cache/codex-runtimes/codex-primary-runtime/dependencies"
    node = runtime_root / "node/bin/node"
    env = os.environ.copy()
    env["NODE_PATH"] = str(runtime_root / "node/node_modules")
    result = subprocess.run([str(node), str(Path(__file__).with_suffix(".cjs"))], env=env)
    raise SystemExit(result.returncode)

from playwright.sync_api import sync_playwright


HERE = Path(__file__).resolve().parent
FULL_SHOW = HERE.parent
REPO = HERE.parents[4]
QA = HERE / "qa"
SOURCE = FULL_SHOW / "romeo-juliet-full-show.stage-sketch.json"
REVISED = HERE / "romeo-juliet-full-show-ai-revised.stage-sketch.json"
REVIEW = HERE / "index.html"
Q03_ID = "rj-frame-rj-cond-01-c-01"
M6_IDS = [
    "rj-frame-rj-cond-01-b-m6-01",
    "rj-frame-rj-cond-01-b-m6-02",
    "rj-frame-rj-cond-01-b-m6-03",
]
EXPECTED_LIGHT = "客席右手前の二人を柔らかく照らし、バーを暖色で見せながら、残る八名にも最低限の明るさを残す。"


class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, _format, *_args):
        pass


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def export_document(page):
    return json.loads(page.evaluate("window.SHOSAI_STAGE_SESSION_BRIDGE.exportDocumentString()"))


def attach_error_capture(page, label: str, errors: list[str]) -> None:
    page.on("pageerror", lambda error: errors.append(f"{label}: pageerror: {error}"))
    page.on(
        "console",
        lambda message: errors.append(f"{label}: console.error: {message.text}")
        if message.type == "error"
        else None,
    )


def import_show(browser, base_url: str, candidate: Path, label: str, errors: list[str]):
    context = browser.new_context(
        viewport={"width": 1440, "height": 1100},
        locale="ja-JP",
        accept_downloads=True,
        service_workers="block",
    )
    context.add_init_script("window.showSaveFilePicker = undefined;")
    page = context.new_page()
    attach_error_capture(page, label, errors)
    page.goto(base_url + "/stage.html", wait_until="domcontentloaded")
    page.wait_for_function("!!window.SHOSAI_STAGE_SESSION_BRIDGE")
    if page.locator("#stage-tour-close").is_visible():
        page.locator("#stage-tour-close").click()

    page.locator("#stage-project-settings-open").click()
    import_label = page.locator("label.stage-import-label").filter(has=page.locator("#stage-import-json"))
    with page.expect_file_chooser() as chooser:
        import_label.click()
    chooser.value.set_files(str(candidate))
    page.locator("#stage-import-modal").wait_for(state="visible")
    summary = page.locator("#stage-import-summary").inner_text()
    expected = json.loads(candidate.read_text(encoding="utf-8"))["project"]
    assert expected["title"] in summary
    page.locator("#stage-import-as-new").click()
    page.wait_for_function(
        "title => JSON.parse(window.SHOSAI_STAGE_SESSION_BRIDGE.exportDocumentString()).project.title === title",
        arg=expected["title"],
    )
    for selector in ("#stage-import-close", "#stage-project-settings-close"):
        if page.locator(selector).is_visible():
            page.locator(selector).click()

    page.locator("#stage-view-select").select_option("plan")
    row = page.locator(f'[data-scene-id="{Q03_ID}"]')
    row.scroll_into_view_if_needed()
    row.locator(".stage-scene-chip").click()
    page.evaluate("window.SHOSAI_STAGE_SESSION_BRIDGE.finishSceneTransition()")
    page.wait_for_timeout(250)
    light_summary = row.locator(".stage-scene-light-summary").inner_text()
    row.screenshot(path=str(QA / f"{label}-q03-light-row.png"))
    page.locator("#stage-plan-cell").screenshot(path=str(QA / f"{label}-q03-stage.png"))
    exported = export_document(page)
    imported_id = exported["project"]["id"]
    assert imported_id != expected["id"], "Open as another show must assign a separate project id"
    context.close()
    return {
        "importSummary": summary,
        "sourceProjectId": expected["id"],
        "importedProjectId": imported_id,
        "lightSummary": light_summary,
        "document": exported,
    }


def main() -> None:
    QA.mkdir(exist_ok=True)
    errors: list[str] = []
    checks: list[str] = []
    handler = lambda *args, **kwargs: QuietHandler(*args, directory=str(REPO), **kwargs)
    server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()
    base_url = f"http://127.0.0.1:{server.server_port}"
    review_path = REVIEW.relative_to(REPO).as_posix()

    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch()
            before = import_show(browser, base_url, SOURCE, "before", errors)
            after = import_show(browser, base_url, REVISED, "after", errors)

            assert before["lightSummary"] == "群れの中で、二人だけが同じ速度になる。"
            assert after["lightSummary"] == EXPECTED_LIGHT
            actual = after["document"]["project"]
            scenes = [scene for scene in actual["scenes"] if scene["kind"] == "scene"]
            assert len(scenes) == 31
            assert len(actual["cast"]) == 10
            assert len(actual["sets"]) == 12
            assert not any(item["id"] == "rj-set-bar-shelf" for item in actual["sets"])
            q03 = next(scene for scene in scenes if scene["id"] == Q03_ID)
            bar = next(piece for piece in q03["pieces"] if piece.get("setId") == "rj-set-bar")
            assert bar["dims"] == {"w": 2.4, "d": 0.75, "h": 1.05}
            assert q03["lightingIntent"]["objective"] == EXPECTED_LIGHT
            assert all(next(scene for scene in scenes if scene["id"] == scene_id)["blackout"] for scene_id in M6_IDS)
            checks.append("元版と改訂版を各々の隔離ブラウザストレージへ『別のショーとして開く』で読み込み")
            checks.append("Q03の平面図とLIGHT行をbefore/after画像として実表示から取得")
            checks.append("改訂版のUI往復後も31シーン・10演者・12セット・バー2.4m・M6技術図3枚を保持")

            review_context = browser.new_context(locale="ja-JP", accept_downloads=True)
            review_page = review_context.new_page()
            attach_error_capture(review_page, "review", errors)
            viewport_results = []
            for width, height in ((1440, 1000), (390, 844)):
                review_page.set_viewport_size({"width": width, "height": height})
                review_page.goto(base_url + "/" + review_path, wait_until="networkidle")
                review_page.wait_for_selector(".decision-button")
                overflow = review_page.evaluate("Math.max(0, document.documentElement.scrollWidth - innerWidth)")
                min_button_height = min(
                    review_page.locator(".decision-button, #save-json, a.download").evaluate_all(
                        "nodes => nodes.map(node => node.getBoundingClientRect().height)"
                    )
                )
                assert overflow == 0
                assert min_button_height >= 44
                for choice in ("B", "C", "A"):
                    review_page.locator(f'.decision-button[data-choice="{choice}"]').click()
                    assert review_page.locator(f'.decision-button[data-choice="{choice}"]').get_attribute("aria-pressed") == "true"
                review_page.screenshot(path=str(QA / f"review-{width}.png"), full_page=True)
                viewport_results.append({"width": width, "height": height, "horizontalOverflowPx": overflow, "minActionHeightPx": round(min_button_height, 2)})

            review_page.locator('.decision-button[data-choice="C"]').click()
            with review_page.expect_download() as download_info:
                review_page.locator("#save-json").click()
            downloaded = json.loads(Path(download_info.value.path()).read_text(encoding="utf-8"))
            downloaded_sets = downloaded["project"]["sets"]
            downloaded_scenes = downloaded["project"]["scenes"]
            shelf_id = "rj-set-bar-shelf-fixed-ai-option-c"
            assert any(item["id"] == shelf_id for item in downloaded_sets)
            assert not any(
                piece.get("setId") == shelf_id
                for scene in downloaded_scenes
                if scene["id"] in M6_IDS
                for piece in scene.get("pieces", [])
            )
            assert all(
                any(piece.get("setId") == shelf_id for piece in next(scene for scene in downloaded_scenes if scene["id"] == scene_id)["pieces"])
                for scene_id in (Q03_ID, "rj-frame-rj-cond-01-d-01")
            )
            checks.append("判断HTMLのA/B/C切替と候補CのJSON保存を実行し、移動バーと固定棚が別ID・別対象であることを確認")
            checks.append("判断HTMLは1440pxと390pxで横はみ出し0、主要操作44px以上")
            review_context.close()
            browser.close()
    finally:
        server.shutdown()
        server.server_close()

    assert not errors, errors
    screenshot_names = [
        "before-q03-stage.png",
        "after-q03-stage.png",
        "before-q03-light-row.png",
        "after-q03-light-row.png",
        "review-1440.png",
        "review-390.png",
    ]
    screenshots = {
        name: {"sha256": sha(QA / name), "bytes": (QA / name).stat().st_size}
        for name in screenshot_names
    }
    report = {
        "status": "pass",
        "baseUrl": base_url,
        "revisedSha256": sha(REVISED),
        "isolatedBrowserStorage": True,
        "userBrowserStorageModified": False,
        "importMode": "別のショーとして開く",
        "beforeProjectIdChanged": before["sourceProjectId"] != before["importedProjectId"],
        "afterProjectIdChanged": after["sourceProjectId"] != after["importedProjectId"],
        "stageViewsChecked": 2,
        "viewports": viewport_results,
        "horizontalOverflowPxMax": max(item["horizontalOverflowPx"] for item in viewport_results),
        "pageAndConsoleErrors": errors,
        "pageAndConsoleErrorCount": len(errors),
        "screenshots": screenshots,
        "checks": checks,
    }
    (QA / "browser-checks.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
